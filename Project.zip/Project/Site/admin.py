from .models import *
from django.contrib import admin 
admin.site.register(Room)
admin.site.register(Message)

