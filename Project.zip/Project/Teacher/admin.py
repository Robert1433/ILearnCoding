from django.contrib import admin

from .models import Teacher,Courses

admin.site.register(Teacher)
admin.site.register(Courses)

